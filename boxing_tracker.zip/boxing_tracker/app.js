const tasks = [
  {id:"warm",name:"Разминка",desc:"5 минут лёгкой разминки"},
  {id:"shadow",name:"Бой с тенью",desc:"3 раунда по 2 минуты"},
  {id:"foot",name:"Работа ног",desc:"3 раунда по 1 минуте"},
  {id:"squat",name:"Приседания",desc:"2 подхода по 12 повторений"},
  {id:"band",name:"Тяга резинки",desc:"2 подхода по 12 повторений"},
  {id:"cool",name:"Заминка",desc:"Спокойная растяжка"}
];
const days=["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"];
let selectedDay="Понедельник";
let completed=JSON.parse(localStorage.getItem("boxing-progress")||"{}");

const daysEl=document.getElementById("days");
const listEl=document.getElementById("taskList");
function renderDays(){
  daysEl.innerHTML="";
  days.forEach(day=>{
    const button=document.createElement("button");
    button.className="day"+(day===selectedDay?" active":"");
    button.textContent=day.slice(0,3);
    button.setAttribute("aria-label",day);
    button.addEventListener("click",()=>{selectedDay=day;render();});
    daysEl.appendChild(button);
  });
}
function renderTasks(){
  listEl.innerHTML="";
  const dayDone=completed[selectedDay]||[];
  tasks.forEach(task=>{
    const label=document.createElement("label");
    label.className="task"+(dayDone.includes(task.id)?" done":"");
    const checkbox=document.createElement("input");
    checkbox.type="checkbox";checkbox.checked=dayDone.includes(task.id);
    checkbox.addEventListener("change",()=>{
      const current=new Set(completed[selectedDay]||[]);
      checkbox.checked?current.add(task.id):current.delete(task.id);
      completed[selectedDay]=[...current];
      localStorage.setItem("boxing-progress",JSON.stringify(completed));
      render();
    });
    const content=document.createElement("span");
    const title=document.createElement("strong");title.textContent=task.name;
    const desc=document.createElement("small");desc.textContent=task.desc;
    content.append(title,desc);label.append(checkbox,content);listEl.appendChild(label);
  });
  const count=dayDone.length, percent=Math.round(count/tasks.length*100);
  document.getElementById("percent").textContent=percent+"%";
  document.getElementById("barFill").style.width=percent+"%";
  document.getElementById("progressText").textContent=`${count} из ${tasks.length} заданий выполнено`;
  document.getElementById("completeMessage").classList.toggle("hidden",count!==tasks.length);
  document.getElementById("selectedDay").textContent=selectedDay;
}
function render(){renderDays();renderTasks();}
document.getElementById("resetBtn").addEventListener("click",()=>{
  completed[selectedDay]=[];
  localStorage.setItem("boxing-progress",JSON.stringify(completed));
  render();
});
render();
